/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Printer, 
  PenTool, 
  Megaphone, 
  BookOpen, 
  Scissors, 
  Gift, 
  CheckCircle, 
  Clock, 
  DollarSign, 
  Menu, 
  X, 
  Phone, 
  Mail, 
  MapPin,
  ChevronRight,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const servicePreviews: { [key: string]: string } = {
    // Imprenta Corporativa
    "Papelería interna empresarial": "/assets/papeleria interna empresarial.jpg",
    "Volantes y Folletos": "/assets/volantes.jpg",
    "Carpetas corporativas": "/assets/carpetas corporativas.jpg",
    "Afiches": "/assets/afiches.jpg",
    "Dípticos y Trípticos": "/assets/tripticos.jpg",
    "Tarjetas de presentación": "/assets/tarjetas de presentacion.jpg",
    // Publicidad
    "Impresión de lonas": "/assets/impresion de lonas.jpg",
    "Roll UPS": "/assets/roll up publicitario.jpg",
    "Letreros": "/assets/muestra 7.jpg",
    "Vallas publicitarias": "/assets/muestra 6.jpg", 
    "Pantallas publicitarias": "/assets/muestra 5.jpg",
    "Material P.O.P": "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=400&q=80",
    // Eventos
    "Tarjetas de matrimonio": "/assets/muestra-2.jpg",
    "Quinceañeras": "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=400&q=80",
    "Bautizos": "/assets/muestra 3.jpg",
    "Eventos empresariales": "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=400&q=80",
    "Invitaciones": "/assets/invitaciones.jpg",
    // Diseño
    "Asesoría publicitaria integral": "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=400&q=80",
    "Creación de logotipos": "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=400&q=80",
    "Identidad visual": "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=400&q=80",
    "Agendas publicitarias": "/assets/muestra 4.jpg",
    // Académico
    "Empastado de Tesis": "/assets/empastado de tesis.jpg",
    "Monografías": "/assets/monografias.jpg",
    "Libros": "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=400&q=80",
    "Bitácoras": "/assets/bitacora.jpg",
  };

  interface ServiceListItemProps {
    item: string;
    highlight?: boolean;
    key?: React.Key;
  }

  const ServiceListItem = ({ item, highlight }: ServiceListItemProps) => {
    const [isHovered, setIsHovered] = useState(false);
    const previewImage = servicePreviews[item];
    
    return (
      <li 
        className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest opacity-80 hover:opacity-100 transition-all group relative cursor-help py-2 border-b border-brand-dark/5 last:border-0"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className={`w-8 h-8 rounded-full overflow-hidden shrink-0 border-2 ${highlight ? 'border-brand-orange' : 'border-brand-blue/30'} group-hover:scale-110 transition-transform`}>
          {previewImage ? (
            <img src={previewImage} alt="" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" />
          ) : (
            <div className={`w-full h-full rotate-45 ${highlight ? 'bg-brand-orange' : 'bg-brand-blue'}`}></div>
          )}
        </div>
        
        <span className="flex-1">{item}</span>
        
        <AnimatePresence>
          {isHovered && previewImage && (
            <motion.div
              initial={{ opacity: 0, x: 20, scale: 0.8 }}
              animate={{ opacity: 1, x: 10, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.8 }}
              className="absolute left-full top-1/2 -translate-y-1/2 z-[100] ml-6 w-56 aspect-video bg-white shadow-2xl p-1 border border-brand-dark/10 pointer-events-none"
            >
              <img 
                src={previewImage} 
                alt={item} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-full left-0 mt-1 bg-brand-dark text-white px-2 py-1 text-[8px] font-black uppercase tracking-widest flex items-center gap-2">
                <span>Zoom Detalle</span>
                <div className="w-1.5 h-1.5 bg-brand-orange animate-pulse rounded-full"></div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </li>
    );
  };

const PubliExpress = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '',
    telefono: '',
    servicio: 'Imprenta Corporativa',
    detalles: ''
  });

  // Handle scroll for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Configuración de WhatsApp
    const phone = "593959099015";
    const text = `*NUEVA SOLICITUD - PUBLI EXPRESS*%0A%0A` +
                 `*Cliente:* ${formData.nombre}%0A` +
                 `*Teléfono:* ${formData.telefono}%0A` +
                 `*Servicio:* ${formData.servicio}%0A` +
                 `*Mensaje:* ${formData.detalles}`;
    
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  const portfolio = [
    {
      title: "Invitaciones 'Elegance FW'",
      category: "Eventos Especiales",
      image: "/src/assets/muestra-1.jpg",
      description: "Papelería fina con monograma personalizado y acabados minimalistas."
    },
    {
      title: "Papelería Law & Partners",
      category: "Imprenta Corporativa",
      image: "https://images.unsplash.com/photo-1586769318280-4415f0d22354?auto=format&fit=crop&w=800&q=80",
      description: "Tarjetas premium con foil dorado y hojas membretadas."
    },
    {
      title: "Campaña 'Verano 2024'",
      category: "Gran Formato",
      image: "https://images.unsplash.com/photo-1603539947678-cd3954ed515d?auto=format&fit=crop&w=800&q=80",
      description: "Vallas publicitarias y lonas de alta resistencia."
    },
    {
      title: "Branding - Studio Lux",
      category: "Diseño & Branding",
      image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80",
      description: "Identidad visual minimalista para estudio de arquitectura."
    }
  ];

  const services = [
    {
      title: "Imprenta Corporativa",
      icon: <Printer className="w-6 h-6 text-brand-blue" />,
      items: ["Papelería interna empresarial", "Volantes y Folletos", "Carpetas corporativas", "Afiches", "Dípticos y Trípticos", "Tarjetas de presentación"]
    },
    {
      title: "Publicidad y Gran Formato",
      icon: <Megaphone className="w-6 h-6 text-white" />,
      items: ["Impresión de lonas", "Roll UPS", "Letreros", "Vallas publicitarias", "Pantallas publicitarias", "Material P.O.P"],
      highlight: true
    },
    {
      title: "Eventos Especiales",
      icon: <Gift className="w-6 h-6 text-brand-blue" />,
      items: ["Tarjetas de matrimonio", "Quinceañeras", "Bautizos", "Eventos empresariales", "Invitaciones"]
    },
    {
      title: "Diseño y Branding",
      icon: <PenTool className="w-6 h-6 text-brand-blue" />,
      items: ["Asesoría publicitaria integral", "Creación de logotipos", "Identidad visual", "Agendas publicitarias"]
    },
    {
      title: "Académico y Encuadernación",
      icon: <BookOpen className="w-6 h-6 text-brand-blue" />,
      items: ["Empastado de Tesis", "Monografías", "Libros", "Bitácoras"]
    }
  ];

  return (
    <div className="font-sans text-brand-dark bg-brand-paper min-h-screen flex flex-col selection:bg-brand-orange selection:text-white">
      
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-500 border-b ${scrolled ? 'bg-white border-brand-dark/10 py-3 shadow-sm' : 'bg-transparent border-transparent py-6'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <div className="w-10 h-10 flex items-center justify-center transition-transform group-hover:rotate-12">
              <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
                <defs>
                  <linearGradient id="gradTop" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#818CF8" />
                    <stop offset="100%" stopColor="#4F46E5" />
                  </linearGradient>
                  <linearGradient id="gradMid" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#38BDF8" />
                    <stop offset="100%" stopColor="#0284C7" />
                  </linearGradient>
                  <linearGradient id="gradBot" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6366F1" />
                    <stop offset="100%" stopColor="#3730A3" />
                  </linearGradient>
                  <radialGradient id="sphereShadow" cx="50%" cy="50%" r="50%" fx="30%" fy="30%">
                    <stop offset="0%" stopColor="white" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="black" stopOpacity="0.1" />
                  </radialGradient>
                </defs>
                
                {/* Spherical Ribbon Layers */}
                {/* Top Cap */}
                <path d="M30 20 Q50 10 70 20 Q75 25 70 30 Q50 20 30 30 Q25 25 30 20 Z" fill="url(#gradTop)" />
                
                {/* Upper Middle */}
                <path d="M15 35 Q50 25 85 35 Q90 42 85 50 Q50 40 15 50 Q10 42 15 35 Z" fill="url(#gradMid)" />
                
                {/* Lower Middle */}
                <path d="M10 55 Q50 45 90 55 Q95 65 90 75 Q50 65 10 75 Q5 65 10 55 Z" fill="url(#gradBot)" />
                
                {/* Bottom Cap */}
                <path d="M25 80 Q50 75 75 80 Q80 85 75 90 Q50 95 25 90 Q20 85 25 80 Z" fill="url(#gradTop)" />
                
                {/* Subtle shine overlay to enhance spherical feel */}
                <circle cx="50" cy="50" r="45" fill="url(#sphereShadow)" pointerEvents="none" />
              </svg>
            </div>
            <h1 className={`text-xl font-black tracking-tighter ${scrolled ? 'text-brand-dark' : 'text-brand-dark lg:text-white'}`}>
              PUBLI EXPRESS <span className="text-brand-orange">DESIGN</span>
            </h1>
          </motion.div>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-10 items-center text-[11px] font-bold uppercase tracking-[0.2em]">
            {['Inicio', 'Servicios', 'Portafolio', 'Beneficios'].map((item) => (
              <a 
                key={item}
                href={`#${item.toLowerCase()}`} 
                className={`hover:text-brand-orange transition-colors relative group ${scrolled ? 'text-brand-dark' : 'text-brand-dark lg:text-white'}`}
              >
                {item}
                <span className="absolute -bottom-2 left-0 w-0 h-[2px] bg-brand-orange transition-all group-hover:w-full"></span>
              </a>
            ))}
            <a href="#contacto" className="bg-brand-dark hover:bg-brand-orange text-white px-6 py-3 transition-colors text-xs font-black uppercase tracking-widest shadow-xl">
              Cotizar Proyecto
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-brand-dark" onClick={toggleMenu}>
            {isMenuOpen ? <X className="w-8 h-8" /> : <Menu className={`w-8 h-8 ${scrolled ? 'text-brand-dark' : 'text-brand-dark lg:text-white'}`} />}
          </button>
        </div>

        {/* Mobile Menu Dropdown */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden bg-white overflow-hidden shadow-2xl border-t border-brand-dark/5"
            >
              <div className="flex flex-col p-6 gap-6 text-xs font-black uppercase tracking-widest">
                <a href="#inicio" onClick={toggleMenu} className="text-brand-dark hover:text-brand-orange">Inicio</a>
                <a href="#servicios" onClick={toggleMenu} className="text-brand-dark hover:text-brand-orange">Servicios</a>
                <a href="#portafolio" onClick={toggleMenu} className="text-brand-dark hover:text-brand-orange">Portafolio</a>
                <a href="#beneficios" onClick={toggleMenu} className="text-brand-dark hover:text-brand-orange">Beneficios</a>
                <a href="#contacto" onClick={toggleMenu} className="bg-brand-dark text-white text-center py-4">Cotizar Ahora</a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="inicio" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        {/* Background side label */}
        <div className="hidden lg:flex absolute left-0 bottom-0 py-12 px-6 [writing-mode:vertical-rl] rotate-180 justify-between h-[80%] border-r border-brand-dark/5 z-20">
          <span className="text-[10px] uppercase tracking-[0.4em] font-black opacity-20">Guayaquil • Ecuador • ©{new Date().getFullYear()}</span>
          <span className="text-[10px] uppercase tracking-[0.4em] font-black opacity-20">Artistic Flair Integrity</span>
        </div>

        <div className="flex w-full h-full flex-col lg:flex-row">
          {/* Content Side */}
          <div className="lg:w-1/2 p-8 lg:p-20 flex flex-col justify-center relative z-10 lg:ml-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative mb-12">
                <span className="absolute -top-10 left-0 bg-brand-orange text-white px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-lg">Nueva Era</span>
                <h2 className="text-6xl md:text-8xl lg:text-[110px] font-black leading-[0.85] tracking-tighter mb-8">
                  TU MARCA <br/>
                  <span className="text-brand-blue italic">DIRECTA.</span>
                </h2>
              </div>
              
              <p className="text-lg md:text-xl leading-relaxed text-brand-dark/60 max-w-lg mb-12 font-medium">
                Diseño, imprenta y branding de alto impacto. Sin intermediarios, ahorrándote el <span className="text-brand-blue font-bold border-b-2 border-brand-orange">15% de comisión</span> habitual.
              </p>

              <div className="flex flex-wrap gap-4">
                <motion.a 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  href="#contacto" 
                  className="px-10 py-5 bg-brand-dark text-white font-black uppercase text-xs tracking-[0.2em] hover:bg-brand-orange transition-colors shadow-2xl flex items-center gap-3"
                >
                  Cotizar Proyecto <ChevronRight className="w-4 h-4" />
                </motion.a>
                <motion.a 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  href="#servicios" 
                  className="px-10 py-5 border border-brand-dark font-black uppercase text-xs tracking-[0.2em] hover:bg-brand-dark hover:text-white transition-all"
                >
                  Ver Portafolio
                </motion.a>
              </div>
            </motion.div>
          </div>

          {/* Visual Side */}
          <div className="lg:w-1/2 h-[50vh] lg:h-auto bg-brand-blue relative flex items-center overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1562577309-4932fdd64cd1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80" 
              alt="Publicidad Directa" 
              className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-overlay grayscale"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-blue to-transparent opacity-80"></div>
            
            <div className="relative w-full p-12 lg:p-20 grid grid-cols-2 gap-4">
               {/* Aesthetic grid elements mirroring the theme */}
               <motion.div 
                 initial={{ opacity: 0, scale: 0.9 }} 
                 animate={{ opacity: 1, scale: 1 }} 
                 transition={{ delay: 0.5 }} 
                 className="aspect-square bg-white relative flex flex-col justify-between shadow-2xl hover:-translate-y-2 transition-transform duration-500 overflow-hidden group/card"
               >
                  <img 
                    src="https://images.unsplash.com/photo-1598133894008-61f7fdb8cc3a?auto=format&fit=crop&w=800&q=80" 
                    alt="Taller de Imprenta" 
                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover/card:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-white/80 to-transparent"></div>
                  <div className="relative p-8 flex flex-col justify-between h-full">
                    <div className="w-12 h-12 bg-white flex items-center justify-center shadow-xl"><Printer className="text-brand-blue" /></div>
                    <h3 className="font-black text-xs uppercase tracking-widest text-brand-dark bg-white inline-block w-fit px-3 py-1 shadow-lg">Imprenta</h3>
                  </div>
               </motion.div>
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }} 
                  animate={{ opacity: 1, scale: 1 }} 
                  transition={{ delay: 0.6 }} 
                  className="aspect-square bg-brand-orange relative flex flex-col justify-between shadow-2xl hover:-translate-y-2 transition-transform duration-500 overflow-hidden group/adv-card text-white"
                >
                  <img 
                    src="https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&w=800&q=80" 
                    alt="Publicidad y Marketing" 
                    className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay group-hover/adv-card:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="relative p-8 flex flex-col justify-between h-full z-10">
                    <div className="w-12 h-12 border border-white/30 flex items-center justify-center bg-brand-orange/20 backdrop-blur-sm shadow-xl"><Megaphone className="text-white" /></div>
                    <h3 className="font-black text-xs uppercase tracking-widest bg-white/20 backdrop-blur-sm inline-block w-fit px-3 py-1 shadow-lg">Publicidad</h3>
                  </div>
                </motion.div>
               <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.7 }} className="col-span-2 bg-brand-dark p-8 flex items-center justify-between text-white hover:bg-brand-blue transition-colors group">
                  <div className="flex-1">
                    <span className="text-[10px] font-bold text-brand-orange uppercase tracking-widest mb-1 block">Branding & Eventos</span>
                    <p className="font-serif italic text-lg leading-tight">Diseño que cuenta historias impactantes.</p>
                  </div>
                  <div className="w-12 h-12 border border-white/20 flex items-center justify-center opacity-40 group-hover:opacity-100 transition-opacity rotate-12"><Star className="w-6 h-6 fill-white" /></div>
               </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-32 bg-white relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            <div className="lg:w-1/3">
              <span className="text-brand-orange font-black uppercase tracking-[0.3em] text-[10px] mb-4 block">Nuestro Valor</span>
              <h3 className="text-5xl font-black text-brand-dark leading-[0.9] tracking-tighter mb-8">¿POR QUÉ NOSOTROS?</h3>
              <p className="text-brand-dark/50 font-medium leading-relaxed">Eliminamos el exceso. Menos procesos, más resultados, mejor inversión.</p>
            </div>

            <div className="lg:w-2/3 grid md:grid-cols-2 gap-1 bg-brand-dark border border-brand-dark">
              {/* Benefit Cards in a Grid with sharp borders */}
              <div className="bg-white p-10 hover:bg-brand-orange hover:text-white transition-all group">
                <DollarSign className="w-10 h-10 text-brand-orange mb-6 group-hover:text-white" />
                <h4 className="text-xl font-bold uppercase tracking-widest mb-4">Precio Directo</h4>
                <p className="text-sm opacity-60 font-medium">Ahorra el 15% que agencias externas cobran por gestión técnica.</p>
              </div>
              <div className="bg-white p-10 hover:bg-brand-blue hover:text-white transition-all group">
                <Clock className="w-10 h-10 text-brand-blue mb-6 group-hover:text-white" />
                <h4 className="text-xl font-bold uppercase tracking-widest mb-4">Rapidez Extrema</h4>
                <p className="text-sm opacity-60 font-medium">Comunicación directa con taller. Tiempos de entrega garantizados.</p>
              </div>
              <div className="bg-white p-10 hover:bg-brand-dark hover:text-white transition-all group">
                <CheckCircle className="w-10 h-10 text-brand-dark mb-6 group-hover:text-white" />
                <h4 className="text-xl font-bold uppercase tracking-widest mb-4">Calidad Premium</h4>
                <p className="text-sm opacity-60 font-medium">Uso de materiales certificados y supervisión técnica constante.</p>
              </div>
              <div className="bg-brand-orange p-10 text-white group">
                 <h4 className="text-4xl font-black italic tracking-tighter mb-4 opacity-30 group-hover:opacity-100 transition-opacity">PED.</h4>
                 <p className="text-xs font-bold uppercase tracking-[0.3em] mt-auto">Solución Integral</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-32 bg-brand-paper border-t border-brand-dark/5">
        <div className="container mx-auto px-6">
          <div className="text-center mb-24">
            <h3 className="text-7xl md:text-9xl font-black text-brand-dark/5 leading-none tracking-tighter absolute left-0 right-0 -mt-10 select-none">SERVICIOS</h3>
            <span className="text-brand-orange font-black uppercase tracking-[0.4em] text-[10px] block relative z-10">Portafolio Completo</span>
            <h4 className="text-4xl font-black text-brand-dark mt-2 relative z-10 tracking-tight italic">Tú lo imaginas, nosotros lo imprimimos.</h4>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div 
                key={index} 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className={`p-10 border border-brand-dark/10 transition-all duration-500 hover:border-brand-dark ${service.highlight ? 'bg-brand-blue text-white' : 'bg-white'}`}
              >
                <div className="mb-8">{service.icon}</div>
                <h4 className="text-xl font-black uppercase tracking-widest mb-6 leading-tight">{service.title}</h4>
                <ul className="space-y-3">
                  {service.items.map((item, i) => (
                    <ServiceListItem key={i} item={item} highlight={service.highlight} />
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portafolio" className="py-32 bg-white relative overflow-hidden">
        {/* Background side label */}
        <div className="hidden lg:flex absolute left-0 bottom-0 py-12 px-6 [writing-mode:vertical-rl] rotate-180 justify-between h-full border-r border-brand-dark/5 z-0">
          <span className="text-[10px] uppercase tracking-[0.5em] font-black opacity-10">Trabajos Recientes • Publicidad Directa</span>
          <div className="w-1 h-20 bg-brand-orange opacity-40 self-center"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div className="max-w-xl">
              <span className="text-brand-orange font-black uppercase tracking-[0.3em] text-[10px] mb-4 block">Resultados Tangibles</span>
              <h3 className="text-5xl md:text-7xl font-black text-brand-dark leading-[0.9] tracking-tighter">TRABAJOS ENTREGADOS</h3>
            </div>
            <p className="text-brand-dark/50 font-medium max-w-xs text-right hidden lg:block border-r-4 border-brand-orange pr-6">
              Cada proyecto es una evidencia de nuestra precisión técnica y compromiso con el diseño de alto nivel.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {portfolio.map((project, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="group cursor-pointer"
              >
                <div className="aspect-[16/10] overflow-hidden bg-brand-paper relative mb-6">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-6 right-6 bg-brand-dark text-white px-4 py-2 text-[9px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {project.category}
                  </div>
                </div>
                <div>
                  <div className="flex items-baseline gap-4 mb-2">
                    <span className="text-brand-orange font-black italic text-lg">0{index + 1}.</span>
                    <h4 className="text-2xl font-bold uppercase tracking-tight text-brand-dark">{project.title}</h4>
                  </div>
                  <p className="text-brand-dark/50 text-sm font-medium tracking-wide">
                    {project.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-24 border-t-2 border-brand-dark pt-12 flex flex-col md:flex-row justify-between items-center gap-10">
             <div className="flex items-center gap-6">
                <div className="w-16 h-[2px] bg-brand-orange"></div>
                <p className="text-xs font-black uppercase tracking-[0.4em]">¿Tienes un desafío similar?</p>
             </div>
             <motion.a 
                whileHover={{ x: 10 }}
                href="#contacto" 
                className="flex items-center gap-4 group text-brand-dark"
              >
                <span className="text-sm font-black uppercase tracking-[0.3em]">Hablemos de tu proyecto</span>
                <div className="w-10 h-10 border border-brand-dark rounded-full flex items-center justify-center group-hover:bg-brand-orange group-hover:border-brand-orange group-hover:text-white transition-all transform group-hover:rotate-45">
                  <ChevronRight />
                </div>
             </motion.a>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-0 border border-brand-dark rounded-none overflow-hidden h-full">
            
            {/* Info Side */}
            <div className="bg-brand-dark text-white p-12 lg:w-1/3 flex flex-col justify-between">
              <div>
                <h3 className="text-4xl font-black italic tracking-tighter mb-10">CONTACTO.</h3>
                <div className="space-y-12">
                  <div className="group cursor-pointer">
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-orange mb-2">WhatsApp</p>
                    <p className="text-xl font-bold group-hover:text-brand-orange transition-colors">+593 959099015</p>
                  </div>
                  <div className="group cursor-pointer">
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-orange mb-2">Email</p>
                    <p className="text-xl font-bold group-hover:text-brand-orange transition-colors underline decoration-1 underline-offset-8">mar_u_amat@hotmail.com</p>
                  </div>
                  <div className="group cursor-pointer">
                    <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-orange mb-2">Sede</p>
                    <p className="text-xl font-bold group-hover:text-brand-orange transition-colors">Guayaquil, Ecuador</p>
                  </div>
                </div>
              </div>
              <div className="mt-20 border-t border-white/10 pt-8 flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-widest opacity-40">Ready to build?</span>
                <div className="w-2 h-2 bg-brand-orange animate-pulse"></div>
              </div>
            </div>

            {/* Form Side */}
            <div className="p-12 lg:w-2/3 bg-brand-paper">
              <h3 className="text-xs font-black uppercase tracking-[0.3em] text-brand-dark mb-12">Enviar Solicitud</h3>
              <form className="grid md:grid-cols-2 gap-x-12 gap-y-10" onSubmit={handleSubmit}>
                <div className="border-b border-brand-dark/20 pb-2 focus-within:border-brand-orange transition-colors">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-40">Nombre</label>
                  <input 
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleInputChange}
                    type="text" 
                    required
                    className="w-full bg-transparent border-none focus:ring-0 px-0 mt-1 font-bold text-brand-dark" 
                    placeholder="Juan P." 
                  />
                </div>
                <div className="border-b border-brand-dark/20 pb-2 focus-within:border-brand-orange transition-colors">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-40">Teléfono</label>
                  <input 
                    name="telefono"
                    value={formData.telefono}
                    onChange={handleInputChange}
                    type="tel" 
                    required
                    className="w-full bg-transparent border-none focus:ring-0 px-0 mt-1 font-bold text-brand-dark" 
                    placeholder="099..." 
                  />
                </div>
                <div className="col-span-full border-b border-brand-dark/20 pb-2 focus-within:border-brand-orange transition-colors">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-40">Servicio Interés</label>
                  <select 
                    name="servicio"
                    value={formData.servicio}
                    onChange={handleInputChange}
                    className="w-full bg-transparent border-none focus:ring-0 px-0 mt-2 font-bold text-brand-dark uppercase tracking-widest text-[11px] cursor-pointer"
                  >
                    <option>Imprenta Corporativa</option>
                    <option>Gran Formato</option>
                    <option>Diseño & Branding</option>
                    <option>Eventos & Academia</option>
                  </select>
                </div>
                <div className="col-span-full border-b border-brand-dark/20 pb-2 focus-within:border-brand-orange transition-colors">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-40">Detalles</label>
                  <textarea 
                    name="detalles"
                    value={formData.detalles}
                    onChange={handleInputChange}
                    rows={3} 
                    required
                    className="w-full bg-transparent border-none focus:ring-0 px-0 mt-1 font-bold text-brand-dark resize-none" 
                    placeholder="Breve mensaje..."
                  ></textarea>
                </div>

                <motion.button 
                  type="submit"
                  whileHover={{ backgroundColor: '#F97316' }}
                  className="bg-brand-dark text-white px-12 py-5 font-black uppercase text-[10px] tracking-[0.4em] transition-colors col-span-full"
                >
                  Confirmar Envío
                </motion.button>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="h-16 px-10 bg-brand-dark text-white flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.3em] mt-auto">
        <div className="flex gap-10">
          <span className="group cursor-pointer">Tel: +593 959099015 <span className="text-brand-orange ml-1">●</span></span>
          <span className="opacity-40">Guayaquil, EC</span>
        </div>
        <div className="hidden md:flex gap-6">
          <span className="opacity-30 hover:opacity-100 transition-opacity cursor-pointer">Estrategia</span>
          <span className="text-brand-orange">Impresión</span>
          <span className="opacity-30 hover:opacity-100 transition-opacity cursor-pointer">Diseño</span>
        </div>
        <div className="opacity-40 text-[9px]">©2024 PUBLI EXPRESS</div>
      </footer>
      
    </div>
  );
};

export default function App() {
  return <PubliExpress />;
}
